HARENNA BOOKS - ANDROID APK PROJECT
===================================

Option 1 (EASIEST - No Android Studio Needed - Free Cloud Build via GitHub):
1. Create a free account on https://github.com and create a new Repository (e.g. harenna-books-apk).
2. Extract this ZIP and upload all files (including the .github folder) to the repository.
3. Click the "Actions" tab on GitHub -> wait ~3 minutes -> click the completed workflow.
4. Under "Artifacts", download "HarennaBooks-APK" -> unzip it and install app-debug.apk on any Android phone!

Option 2 (Android Studio on PC):
1. Open Android Studio -> "Open" -> select this extracted folder.
2. Wait for Gradle Sync to finish.
3. Click Build -> Build Bundle(s) / APK(s) -> Build APK(s).
4. For Google Play Store release: Build -> Generate Signed Bundle / APK (.aab).

Security Included:
- FLAG_SECURE enabled (Blocks Screenshots & Screen Recording on Android)
- Persistent Login Cookies & File Upload support (for Author Studio)
- Direct HTTPS connection to https://harennabooks.dessiesmartcity.org.et
